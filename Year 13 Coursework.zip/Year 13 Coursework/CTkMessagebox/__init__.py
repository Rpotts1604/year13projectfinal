"""
CustomTkinter Messagebox
Author: Akash Bora
This is a modern messagebox made with customtkinter.
Homepage: https://github.com/Akascape/CTkMessagebox
"""

__version__ = '2.7'

from .ctkmessagebox import CTkMessagebox

