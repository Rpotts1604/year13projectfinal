#external packages
from customtkinter import *
import customtkinter as ctk
from tkinter import *
from CTkMessagebox import *
from time import sleep

#internal packages
import adminPortal
import customerPortal




#Customer username and password validation check
def customerLoginCheck(username, password, root, detailsFrame, buttonsFrame):
    f = open('customerlogins.txt', 'r')
    for line in f:
        splitLine = line.split(',')
        if splitLine[0] == username and splitLine[1] == password:
            customerPortal.customerPortalWin(username, root, detailsFrame, buttonsFrame)
            return
    CTkMessagebox(root, title='ERROR', message='Login not found')


#Admin username and password validation check
def adminLoginCheck(username, password, root, detailsFrame, buttonsFrame):

    f = open('adminlogins.txt', 'r')
    for line in f:
        splitLine = line.split(',')
        if splitLine[0] == username and splitLine[1] == password:
            adminPortal.adminPortalWin(root, detailsFrame, buttonsFrame)  
            return
    CTkMessagebox(root, title='ERROR', message='Login not found')

#Admin login screen
def adminLogin(mainMenuFrame):
    mainMenuFrame.destroy()
    root.title('Customer Login')
    
    detailsFrame = CTkFrame(root)
    buttonsFrame = CTkFrame(root)

    CTkLabel(detailsFrame, text='Username', font=default_font).grid(row=0, column=0, pady=(0, 10), padx=(0, 10))
    usernameEntry = CTkEntry(detailsFrame)
    usernameEntry.grid(row=0, column=1, pady=(0, 10))
    
    CTkLabel(detailsFrame, text='Password', font=default_font).grid(row=1, column=0, pady=(10, 0), padx=(0, 10))
    passwordEntry = CTkEntry(detailsFrame)
    passwordEntry.grid(row=1, column=1, pady=(10, 0))
    
    loginButton = CTkButton(buttonsFrame, text='Login', font=default_font, command=lambda: adminLoginCheck(usernameEntry.get(), passwordEntry.get(), root, detailsFrame, buttonsFrame))
    loginButton.grid(row=0, column=0, pady=(10, 0))

    backButton = CTkButton(buttonsFrame, text='back', font=default_font, command=lambda: mainMenu(detailsFrame, buttonsFrame))
    backButton.grid(row=1, column=0, pady=(10, 0))
    
    detailsFrame.place(relx=.5, rely=.5, anchor='c')
    buttonsFrame.place(relx=.5, rely=.8, anchor='c')



#Customer login screen
def customerLogin(mainMenuFrame):
    mainMenuFrame.destroy()
    root.title('Customer Login')
    
    detailsFrame = CTkFrame(root)
    buttonsFrame = CTkFrame(root)

    CTkLabel(detailsFrame, text='Halo ID', font=default_font).grid(row=0, column=0, pady=(0, 10), padx=(0, 10))
    usernameEntry = CTkEntry(detailsFrame)
    usernameEntry.grid(row=0, column=1, pady=(0, 10))
    
    CTkLabel(detailsFrame, text='Password', font=default_font).grid(row=1, column=0, pady=(10, 0), padx=(0, 10))
    passwordEntry = CTkEntry(detailsFrame)
    passwordEntry.grid(row=1, column=1, pady=(10, 0))
    
    loginButton = CTkButton(buttonsFrame, text='Login', font=default_font, command=lambda: customerLoginCheck(usernameEntry.get(), passwordEntry.get(), root, detailsFrame, buttonsFrame))
    loginButton.grid(row=0, column=0, pady=(10, 0))

    backButton = CTkButton(buttonsFrame, text='back', font=default_font, command=lambda: mainMenu(detailsFrame, buttonsFrame))
    backButton.grid(row=1, column=0, pady=(10, 0))
    
    detailsFrame.place(relx=.5, rely=.5, anchor='c')
    buttonsFrame.place(relx=.5, rely=.8, anchor='c')
        

#main menu on startup

root = CTk()
ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')
root.geometry('600x600')
root.maxsize(600, 600)
root.minsize(600, 600)
root.title('Halo Leisure Login Portal')
default_font = CTkFont(family='Microsoft YaHei')

def mainMenu(detailsFrame, buttonsFrame):
    detailsFrame.destroy()
    buttonsFrame.destroy()
    mainMenuFrame = CTkFrame(root)
    mainMenuFrame.configure(width=600, height=600)


    logo = PhotoImage(file='images\halo-logo.png')
    CTkLabel(mainMenuFrame,image=logo, font=('Microsoft YaHei', 55), text='').place(relx=.5, rely=.25, anchor='c')

    customerLoginButton = CTkButton(mainMenuFrame, text='Customer\nLogin', command=lambda:customerLogin(mainMenuFrame), font=('Microsoft YaHei', 25))
    customerLoginButton.place(relx=.33, rely=.5, anchor='c')

    adminLoginButton = CTkButton(mainMenuFrame, text='Administrator\nLogin', command=lambda:adminLogin(mainMenuFrame), font=('Microsoft YaHei', 25))
    adminLoginButton.place(relx=.66, rely=.5, anchor='c')

    mainMenuFrame.place(rely=.5, relx=.5, anchor='c')

detailsFrame = CTkFrame(root)
buttonsFrame = CTkFrame(root)
mainMenu(detailsFrame, buttonsFrame)
root.mainloop()